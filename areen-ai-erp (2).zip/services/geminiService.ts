// services/geminiService.ts

import { GoogleGenAI, Type } from "@google/genai";
import { ChartData, CashFlowEntry, CashFlowForecast, ProactiveInsight } from '../types';

// Per guidelines, initialize with API_KEY from environment variables.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const model = 'gemini-2.5-flash';

const generateFinancialSummary = async (data: ChartData[]): Promise<string> => {
  const prompt = `
    Analyze the following financial data which represents monthly income and expense in IDR.
    Provide a concise summary of the financial performance.
    Highlight key trends, highest/lowest points, and potential areas for concern or opportunity.
    The output should be in simple markdown format. Use ** for headings and * for list items.

    Data:
    ${JSON.stringify(data)}
    `;

  const response = await ai.models.generateContent({
    model: model,
    contents: prompt,
  });

  return response.text;
};

const getChatbotResponse = async (userInput: string): Promise<string> => {
  // This is a simplified chatbot. For a real app, we'd use ai.chats.create for conversation history.
  // Given the current implementation in Chatbot.tsx, a one-off response is what's expected.
  const prompt = `
    You are an AI assistant for an ERP system.
    Answer the user's question concisely based on general business knowledge.
    Do not mention that you are an AI.
    User's question: "${userInput}"
    `;

  const response = await ai.models.generateContent({
    model: model,
    contents: prompt,
  });
  
  return response.text;
};


const getLeadScoreAndNextAction = async (dealName: string, dealValue: number): Promise<{ score: number; action: string; }> => {
    const prompt = `
      Analyze the following sales deal and provide a lead score (0-100) and a concise next action suggestion.
      - Deal Name: "${dealName}"
      - Deal Value: IDR ${dealValue}
      
      Consider factors like deal value and keywords in the name (e.g., 'upgrade', 'maintenance', 'contract' are positive).
      Return a JSON object with two keys: "score" (a number) and "action" (a string).
    `;

    const response = await ai.models.generateContent({
        model: model,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    score: { type: Type.NUMBER, description: "Lead score from 0 to 100" },
                    action: { type: Type.STRING, description: "Suggested next action for the sales team" }
                },
                required: ['score', 'action']
            }
        }
    });
    
    // As per docs, response.text is a JSON string.
    let jsonStr = response.text.trim();
    // It might be wrapped in markdown
    if (jsonStr.startsWith('```json')) {
        jsonStr = jsonStr.substring(7, jsonStr.length - 3).trim();
    } else if (jsonStr.startsWith('`')) {
        jsonStr = jsonStr.substring(1, jsonStr.length - 1).trim();
    }
    const parsed = JSON.parse(jsonStr);
    return {
        score: parsed.score,
        action: parsed.action
    };
};

const getCashFlowForecast = async (data: CashFlowEntry[]): Promise<CashFlowForecast> => {
    const prompt = `
        Based on the following historical cash flow data (in IDR) for the last 6 months, generate a forecast for the next 30, 60, and 90 days.
        Also, provide a brief "warning" string if you detect a potential negative cash flow or a significant downturn. If there are no warnings, return an empty string for the warning.
        
        Historical Data:
        ${JSON.stringify(data)}

        Return a JSON object with keys: "forecast30", "forecast60", "forecast90" (all numbers), and "warning" (a string).
    `;

    const response = await ai.models.generateContent({
        model: model,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    forecast30: { type: Type.NUMBER },
                    forecast60: { type: Type.NUMBER },
                    forecast90: { type: Type.NUMBER },
                    warning: { type: Type.STRING }
                },
                required: ['forecast30', 'forecast60', 'forecast90', 'warning']
            }
        }
    });

    let jsonStr = response.text.trim();
    if (jsonStr.startsWith('```json')) {
        jsonStr = jsonStr.substring(7, jsonStr.length - 3).trim();
    } else if (jsonStr.startsWith('`')) {
        jsonStr = jsonStr.substring(1, jsonStr.length - 1).trim();
    }
    const parsed = JSON.parse(jsonStr);
    
    return {
        ...parsed,
        warning: parsed.warning || null,
    };
};

const getProactiveInsights = async (erpData: object): Promise<ProactiveInsight[]> => {
    const prompt = `
        You are an expert AI business analyst for an ERP system.
        Analyze the provided JSON data which includes invoices, products, deals, and bills.
        Identify the top 3-5 most critical or valuable insights. Categorize each insight as one of the following: 'Anomaly', 'Opportunity', or 'Efficiency'.
        
        - 'Anomaly': Unexpected negative trends, significant drops in sales for a product, overdue high-value invoices, etc.
        - 'Opportunity': Potential for cross-selling based on customer behavior, deals with high lead scores needing a push, products that could be bundled.
        - 'Efficiency': Suggestions for cost savings, vendors that are consistently expensive, etc.

        Provide a concise title and a short description for each insight.

        Business Data Context:
        ${JSON.stringify(erpData, null, 2).substring(0, 5000)}...
        (Data has been truncated for brevity)
    `;

    const response = await ai.models.generateContent({
        model: model,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: {
                        type: { type: Type.STRING, enum: ['Anomaly', 'Opportunity', 'Efficiency'] },
                        title: { type: Type.STRING },
                        description: { type: Type.STRING }
                    },
                    required: ['type', 'title', 'description']
                }
            }
        }
    });

    let jsonStr = response.text.trim();
    if (jsonStr.startsWith('```json')) {
        jsonStr = jsonStr.substring(7, jsonStr.length - 3).trim();
    } else if (jsonStr.startsWith('`')) {
        jsonStr = jsonStr.substring(1, jsonStr.length - 1).trim();
    }
    const parsed = JSON.parse(jsonStr);
    return parsed as ProactiveInsight[];
};

const analyzeDataWithQuestion = async (userQuestion: string, contextData: object): Promise<string> => {
    const prompt = `
        You are an AI business analyst for an ERP system. 
        Analyze the provided JSON business data to answer the user's question. 
        Provide a clear, concise, and helpful response. 
        If the data is insufficient to answer, state that and explain what information is missing. 
        Format your response using simple markdown (e.g., use ** for bold, * for list items).
        
        User Question: "${userQuestion}"

        Business Data Context (truncated): 
        ${JSON.stringify(contextData, null, 2).substring(0, 5000)}
    `;

    const response = await ai.models.generateContent({
        model: model,
        contents: prompt,
    });
    return response.text;
};


export const geminiService = {
  generateFinancialSummary,
  getChatbotResponse,
  getLeadScoreAndNextAction,
  getCashFlowForecast,
  getProactiveInsights,
  analyzeDataWithQuestion,
};