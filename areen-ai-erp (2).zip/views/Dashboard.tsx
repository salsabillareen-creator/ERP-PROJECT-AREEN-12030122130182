// views/Dashboard.tsx
import React, { useMemo } from 'react';
import { BarChart, Bar, PieChart, Pie, Cell, AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { 
    MOCK_INVOICES,
    MOCK_BILLS,
    MOCK_LEDGER_DATA,
    MOCK_TOP_PRODUCTS_CHART,
    MOCK_PROJECT_STATUS_CHART,
    MOCK_INCOME_VS_EXPENSE_CHART,
    MOCK_PROJECT_TASKS,
} from '../constants';
import { InvoiceStatus, BillStatus, AccountType, TaskPriority } from '../types';
import { WarningIcon, CalendarIcon, BriefcaseIcon, DollarSignIcon, TrendingUpIcon, TrendingDownIcon, ChevronsUpIcon, ChevronUpIcon, EqualIcon } from '../components/icons';
import { useTheme } from '../contexts/ThemeContext';

const priorityIcons: { [key in TaskPriority]: React.ReactNode } = {
    [TaskPriority.High]: <ChevronsUpIcon className="w-4 h-4 text-red-500" />,
    [TaskPriority.Medium]: <ChevronUpIcon className="w-4 h-4 text-yellow-500" />,
    [TaskPriority.Low]: <EqualIcon className="w-4 h-4 text-green-500" />,
};

const WelcomeIllustration: React.FC = () => (
    <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
        <path fill="var(--color-primary)" d="M48.4,-65.4C63,-51.9,75.4,-35.1,79.1,-16.9C82.8,1.2,77.8,20.8,67.7,37.1C57.6,53.4,42.4,66.4,25.4,73.5C8.4,80.6,-10.4,81.8,-27.9,76.1C-45.4,70.4,-61.6,57.8,-69.8,42.2C-78.1,26.6,-78.4,8.1,-73.9,-9.1C-69.5,-26.3,-60.3,-42.2,-47.9,-55.6C-35.4,-69,-19.7,-79.9,-1.1,-78.9C17.5,-77.9,33.9,-78.9,48.4,-65.4Z" transform="translate(100 100) scale(1.1)" opacity="0.1"/>
    </svg>
);


interface DashboardProps {
    setCurrentView: (view: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ setCurrentView }) => {
    const { primaryColor } = useTheme();
    const projectStatusColors = [primaryColor, '#e5e7eb'];
    
    const formatCurrency = (value: number) => `Rp ${new Intl.NumberFormat('id-ID').format(value)}`;

    const { totalRevenue, totalExpenses, netProfit, overdueInvoicesCount, upcomingBillsCount } = useMemo(() => {
        const totalRevenue = MOCK_LEDGER_DATA.filter(e => e.type === AccountType.Revenue).reduce((sum, item) => sum + item.amount, 0);
        const totalExpenses = MOCK_LEDGER_DATA.filter(e => e.type === AccountType.Expense).reduce((sum, item) => sum + item.amount, 0);
        const netProfit = totalRevenue - totalExpenses;
        const overdueInvoicesCount = MOCK_INVOICES.filter(i => i.status === InvoiceStatus.Overdue).length;
        const upcomingBillsCount = MOCK_BILLS.filter(b => b.status === BillStatus.Upcoming).length;
        return { totalRevenue, totalExpenses, netProfit, overdueInvoicesCount, upcomingBillsCount };
    }, []);
    
    const myTasks = MOCK_PROJECT_TASKS.slice(0, 4); // Get first 4 tasks for "My Tasks"

    return (
        <div className="p-6 bg-gray-50/50 min-h-full">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

                {/* Left Column */}
                <div className="lg:col-span-8 space-y-6">
                    {/* Welcome Banner */}
                    <div className="relative bg-white p-8 rounded-2xl shadow-sm overflow-hidden border border-gray-100">
                        <div className="absolute -right-20 -top-20 w-80 h-80 z-0">
                            <WelcomeIllustration />
                        </div>
                        <div className="relative z-10">
                            <h1 className="text-3xl font-bold text-gray-800">Selamat Datang Kembali!</h1>
                            <p className="mt-2 text-gray-500">Berikut adalah ringkasan cepat aktivitas bisnis Anda hari ini.</p>
                        </div>
                    </div>
                    
                    {/* Financial Snapshot */}
                     <div className="bg-white p-6 rounded-xl shadow-sm">
                         <h2 className="text-lg font-semibold text-gray-700 mb-4">Ringkasan Finansial</h2>
                         <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div 
                                onClick={() => setCurrentView('reports')}
                                className="bg-gray-50 p-5 rounded-lg text-center cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
                                <TrendingUpIcon className="w-8 h-8 mx-auto text-green-500 mb-2"/>
                                <p className="text-sm text-gray-500">Total Pendapatan</p>
                                <p className="text-2xl font-bold text-gray-800 mt-1">{formatCurrency(totalRevenue)}</p>
                            </div>
                             <div 
                                onClick={() => setCurrentView('reports')}
                                className="bg-gray-50 p-5 rounded-lg text-center cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
                                <TrendingDownIcon className="w-8 h-8 mx-auto text-red-500 mb-2"/>
                                <p className="text-sm text-gray-500">Total Pengeluaran</p>
                                <p className="text-2xl font-bold text-gray-800 mt-1">{formatCurrency(totalExpenses)}</p>
                            </div>
                             <div 
                                onClick={() => setCurrentView('reports')}
                                className="bg-gray-50 p-5 rounded-lg text-center cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
                                <DollarSignIcon className="w-8 h-8 mx-auto text-blue-500 mb-2"/>
                                <p className="text-sm text-gray-500">Laba Bersih</p>
                                <p className={`text-2xl font-bold mt-1 ${netProfit >= 0 ? 'text-gray-800' : 'text-red-600'}`}>{formatCurrency(netProfit)}</p>
                            </div>
                        </div>
                    </div>

                    {/* Quick Access */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="bg-white p-6 rounded-xl shadow-sm">
                             <h2 className="text-lg font-semibold text-gray-700 mb-4">Akses Cepat</h2>
                             <div className="space-y-4">
                                <div className="flex items-center justify-between bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                                    <div className="flex items-center gap-3">
                                        <WarningIcon className="w-6 h-6 text-yellow-500 flex-shrink-0"/>
                                        <div>
                                            <p className="font-semibold text-yellow-800">Faktur Jatuh Tempo</p>
                                            <p className="text-sm text-yellow-700">{overdueInvoicesCount} faktur perlu ditindaklanjuti</p>
                                        </div>
                                    </div>
                                    <button onClick={() => setCurrentView('sales')} className="text-sm font-semibold text-yellow-800 hover:underline">Lihat</button>
                                </div>
                                <div className="flex items-center justify-between bg-blue-50 p-4 rounded-lg border border-blue-200">
                                     <div className="flex items-center gap-3">
                                        <CalendarIcon className="w-6 h-6 text-blue-500 flex-shrink-0"/>
                                        <div>
                                            <p className="font-semibold text-blue-800">Tagihan Mendatang</p>
                                            <p className="text-sm text-blue-700">{upcomingBillsCount} tagihan harus dibayar</p>
                                        </div>
                                    </div>
                                    <button onClick={() => setCurrentView('purchases')} className="text-sm font-semibold text-blue-800 hover:underline">Lihat</button>
                                </div>
                             </div>
                        </div>
                        {/* Interactive Charts Placeholder or another widget can go here */}
                         <div className="bg-white p-6 rounded-xl shadow-sm">
                            <h3 className="font-medium text-gray-600 text-center text-sm mb-2">Status Proyek Kritis</h3>
                            <ResponsiveContainer width="100%" height={160}>
                                 <PieChart>
                                    <Pie data={MOCK_PROJECT_STATUS_CHART} dataKey="value" cx="50%" cy="50%" innerRadius={40} outerRadius={60} paddingAngle={5}>
                                        {MOCK_PROJECT_STATUS_CHART.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={projectStatusColors[index % projectStatusColors.length]} />
                                        ))}
                                    </Pie>
                                    <Tooltip />
                                    <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle" className="text-2xl font-bold fill-gray-800">
                                        {`${MOCK_PROJECT_STATUS_CHART[0].value}%`}
                                    </text>
                                     <text x="50%" y="65%" textAnchor="middle" dominantBaseline="middle" className="text-xs fill-gray-500">
                                        Selesai
                                    </text>
                                </PieChart>
                            </ResponsiveContainer>
                        </div>
                    </div>

                    {/* Visual Analysis */}
                    <div className="bg-white p-6 rounded-xl shadow-sm">
                         <h2 className="text-lg font-semibold text-gray-700 mb-4">Analisis Visual</h2>
                         <div className="grid grid-cols-1 gap-6">
                            <div>
                                <h3 className="font-medium text-gray-600 text-sm mb-2">Top 5 Produk Terlaris</h3>
                                <ResponsiveContainer width="100%" height={200}>
                                    <BarChart data={MOCK_TOP_PRODUCTS_CHART} layout="vertical" margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                                        <XAxis type="number" hide />
                                        <YAxis type="category" dataKey="name" tickLine={false} axisLine={false} tick={{fontSize: 12}} />
                                        <Tooltip cursor={{fill: '#f3f4f6'}} contentStyle={{backgroundColor: 'white', borderRadius: '8px', borderColor: '#e5e7eb'}}/>
                                        <Bar dataKey="value" fill={primaryColor} radius={[0, 4, 4, 0]} barSize={15} />
                                    </BarChart>
                                </ResponsiveContainer>
                            </div>
                            <div>
                                <h3 className="font-medium text-gray-600 text-sm mb-2">Tren Pendapatan vs. Pengeluaran</h3>
                                <ResponsiveContainer width="100%" height={200}>
                                    <AreaChart data={MOCK_INCOME_VS_EXPENSE_CHART} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                                        <XAxis dataKey="name" tick={{fontSize: 12}} />
                                        <YAxis tick={{fontSize: 12}} />
                                        <Tooltip contentStyle={{backgroundColor: 'white', borderRadius: '8px', borderColor: '#e5e7eb'}}/>
                                        <Area type="monotone" dataKey="income" stackId="1" stroke="#82ca9d" fill="#82ca9d" />
                                        <Area type="monotone" dataKey="expense" stackId="1" stroke="#ffc658" fill="#ffc658" />
                                    </AreaChart>
                                </ResponsiveContainer>
                            </div>
                         </div>
                    </div>
                </div>

                {/* Right Column */}
                <div className="lg:col-span-4">
                    <div className="bg-white p-6 rounded-xl shadow-sm h-full">
                        <h2 className="text-lg font-semibold text-gray-700 mb-4">Tugas Saya</h2>
                        <ul className="space-y-4">
                            {myTasks.map(task => (
                                <li key={task.id} className="flex items-center justify-between p-3 bg-gray-50/50 rounded-lg">
                                    <div className="flex items-center gap-3">
                                        <BriefcaseIcon className="w-5 h-5 text-gray-400"/>
                                        <div>
                                            <p className="text-sm font-medium text-gray-700">{task.title}</p>
                                            <p className="text-xs text-gray-500">In project "Phoenix"</p>
                                        </div>
                                    </div>
                                    {priorityIcons[task.priority]}
                                </li>
                            ))}
                        </ul>
                         <button onClick={() => setCurrentView('projects')} className="w-full mt-4 text-sm font-semibold text-[var(--color-primary)] hover:underline">
                            Lihat Semua Tugas
                        </button>
                    </div>
                </div>

            </div>
        </div>
    );
};

export default Dashboard;